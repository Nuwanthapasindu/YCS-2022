<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
Dear


Your

<h6>Dear <?php echo e($data['name']); ?>, Your <?php echo e($data['role']); ?> account has been successfully created. You can now log in to your account.</h6>
<table>
    <tr>
        <th>email</th>
        <td>Your Email Address</td>
    </tr>
        <th>password</th>
        <td><?php echo e($data['password']); ?></td>
    </tr>
    <tr>
        <th>Link</th>
        <td><?php echo e(env('APP_FRONTEND_URL')); ?></td>
    </tr>
</table>
</body>
</html>
<?php /**PATH D:\VueLaravel\YCS-competition\server\resources\views/emails/new_account.blade.php ENDPATH**/ ?>