<?php

namespace App\enum;

enum roles:string
{
   case ADMIN = "admin";
   case SECTION_HEAD = "section_head";
   case TEACHER = "teacher";
}
